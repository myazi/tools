#########################################################################
# File Name: author.sh
# Author: yingwenjie
# mail: yingwenjie.com
# Created Time: Wed 27 May 2021 12:05:12 PM CST
#########################################################################
#!/bin/bash
source ~/.bashrc
source ~/.bash_profile
ROOT_DIR="."
DATA_DIR="./data"
BIN="./bin"
LOG_DIR="./log"
email="yingwenjie@baidu.com"
day=`date -d "-1 days" +%Y%m%d`
cd shangyang_fufei_cold_start_video_hash_icf
if [ ! -d ./data ]; then
    mkdir ./data
fi
rm -rf  ./data/argfile_tmp
rm -rf ./data/segfile_tmp
rm -rf ./data/tfidffile_tmp
mkdir ./data/argfile_tmp
mkdir ./data/segfile_tmp
mkdir ./data/tfidffile_tmp
if [ ! -r pytorch ]; then
    if [ ! -s pytorch.tar ]; then
        hadoop fs -D hadoop.job.ugi="feed_vertical,Tg28D3" -D fs.default.name=afs://tianqi.afs.baidu.com:9902 -get afs://tianqi.afs.baidu.com:9902/user/feed/vertical/job_data/production/vertical_common/yingwenjie/tuwendaihuo_author_data/pytorch.tar ${ROOT_DIR}
        tar -zxvf pytorch.tar
    fi
    if [ ! -r pytorch ]; then
        echo "miss pytorch"
        exit -1
    fi
fi
if [ -f ${DATA_DIR}/info_fufei_new ]; then
    rm ${DATA_DIR}/info_fufei_new
fi
if [ ! -s ${DATA_DIR}/info_fufei_new ]; then
    hadoop fs -D hadoop.job.ugi="feed_vertical,Tg28D3" -D fs.default.name=afs://tianqi.afs.baidu.com:9902 -get afs://tianqi.afs.baidu.com:9902/user/feed/vertical/job_data/production/vertical_common/yingwenjie/fufei/info_fufei_new ${DATA_DIR}
fi
if [ ! -s ${DATA_DIR}/info_fufei_new ]; then
    echo "miss info_fufei_new"
    exit -1
fi

if [ -f ${DATA_DIR}/cuid_nid_click_pay ]; then
    rm ${DATA_DIR}/cuid_nid_click_pay
fi
if [ ! -s ${DATA_DIR}/cuid_nid_click_pay ]; then
    hadoop fs -D hadoop.job.ugi="feed_vertical,Tg28D3" -D fs.default.name=afs://tianqi.afs.baidu.com:9902 -get afs://tianqi.afs.baidu.com:9902/user/feed/vertical/job_data/production/vertical_common/yingwenjie/fufei/cuid_nid_click_pay ${DATA_DIR}
fi
if [ ! -s ${DATA_DIR}/cuid_nid_click_pay ]; then
    echo "miss cuid_nid_click_pay"
    exit -1
fi

if [ -f ${DATA_DIR}/info_fufei ]; then
    rm ${DATA_DIR}/info_fufei
fi
if [ ! -s ${DATA_DIR}/info_fufei ]; then
    hadoop fs -D hadoop.job.ugi="feed_vertical,Tg28D3" -D fs.default.name=afs://tianqi.afs.baidu.com:9902 -get afs://tianqi.afs.baidu.com:9902/user/feed/vertical/job_data/production/vertical_common/wangmengfei01/fufei/info/${day}/info_${day} ${DATA_DIR}/info_fufei
fi
if [ ! -s ${DATA_DIR}/info_fufei ]; then
    echo "miss info_fufei"
    exit -1
fi
cat ${DATA_DIR}/info_fufei_new ${DATA_DIR}/info_fufei > ${DATA_DIR}/info_fufei_tmp
awk -F "\t" '{if($2=="video") print $1"\t"$5"\t"$12"\t"$3"\t"$16"\t""author""\t""author_level""\t""tags""\t""general_tag""\t"$8"\t""video_type""\t""realurl""\t""video_duration""\t"$6"\t"$7"\t""bjh_is_v""\t""is_microvideo""\t""1"}' ${DATA_DIR}/info_fufei_tmp > ${DATA_DIR}/info_fufei_tmp2
cat ${DATA_DIR}/info_fufei_tmp2 | sort -t $'\t' -u -k 1,1 > ${DATA_DIR}/zhengpai_fufei_is_pay
/opt/compiler/gcc-8.2/lib/ld-linux-x86-64.so.2 --library-path /opt/compiler/gcc.8.2/lib ./pytorch/bin/python3 ${BIN}/hash/SemHash8.py ${DATA_DIR}/zhengpai_fufei_is_pay 10 50000 32 100000000 10

/opt/compiler/gcc-8.2/lib/ld-linux-x86-64.so.2 --library-path /opt/compiler/gcc.8.2/lib ./pytorch/bin/python3 ${BIN}/hash/doc_sim_demo.py ${DATA_DIR}/cuid_nid_click_pay
if [ ! ${DATA_DIR}/fufei_cold_start_video_hash_icf_dict ]; then
    echo "miss dict"
    exit -1
fi
mv ${DATA_DIR}/fufei_cold_start_video_hash_icf_dict ../data/fufei_cold_start_video_hash_icf_dict
md5sum ../data/fufei_cold_start_video_hash_icf_dict > ../data/fufei_cold_start_video_hash_icf_dict.md5
exit 0

