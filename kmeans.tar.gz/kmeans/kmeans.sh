cluster_num=(8 10 12 16 24)
#cluster_files=(xx_fangdichan xx_huahzuang xx_jiaju xx_jiankangyangsheng xx_jiaoyu xx_lvyou xx_meishi xx_qiche xx_shuma)
#cluster_files=(xx_fangdichan_query xx_huahzuang_query xx_jiaju_query xx_jiankangyangsheng_query xx_jiaoyu_query xx_lvyou_query xx_meishi_query xx_qiche_query xx_shuma_query)
cluster_files=(xx_jiaoyu_query)
for cluster_file in ${cluster_files[@]}
do
    for cluster in ${cluster_num[@]}
    do
        output_cluster=./data/res_${cluster_file}_${cluster}
        /home/yanghaihua/anaconda2/envs/pytorch/bin/python3 ./bin/kmeans.py ./data/$cluster_file $cluster > ${output_cluster}
        cat ${output_cluster} | python ./bin/evaluation.py > ./data/res_${cluster_file}_${cluster}_evaluation
        output_png=./data/png_${cluster_file}_${cluster}
        rm -rf ${output_png}
        mkdir ${output_png} 
        cat ${output_cluster} | /home/yanghaihua/anaconda2/envs/pytorch/bin/python3 ./bin/wc.py ${output_png}  
    done
done

#sort -t $'\t' -k 1n ./data/res_kmeans_jiaoyu_12 > ./data/sort_res_kmeans_jiaoyu_12
#python ./bin/random_sample.py ./data/sort_res_kmeans_qinggan > ./data/random_res_kmeans_qinggan
#sort -t $'\t' -k 3n ./data/random_res_kmeans_qinggan > ./data/sort_random_res_kmeans_qinggan
