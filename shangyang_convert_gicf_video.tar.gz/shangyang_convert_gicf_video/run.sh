#!/bin/bash
hadoop=/home/biglog/feed_tools/hmpclient/hadoop-client/hadoop/bin/hadoop

# 获取时间
hour=`date +%Y%m%d%H -d  '-1 hour'`
day=${hour:0:8}
HOUR=${hour:8:2}
echo "${hour} hour" 
echo "${day} day" 


# todo 单进程运行，后续要删除
IP_FILE='run_daily.pid'
if [ -f ./$IP_FILE ];then
    date +%Y-%m-%d:%H-%M-%S
    echo "not over!"
    echo "gicf not over" | mutt shijin01@baidu.com,liushaojie06@baidu.com,xiaotao02@baidu.com,yingwenjie@baidu.com,huanghua02@baidu.com,wangpeijian01@baidu.com,liguanghui02@baidu.com,wangchangzhi@baidu.com,wenhao04@baidu.com,zhangxiang20@baidu.com -s "last not finish"
    exit
fi
echo "${hour} PID of this script: $$" > ./$IP_FILE

dict=convert_gicf_news
# todo 先在本地机器跑，下面这行先注释。
#cd ./shangyang_${dict}/
if [ ! -d ./data ]; then
	mkdir ./data
fi
rm -rf ./data/*

# 获取含有annoy包的python
readonly RETRY=3
for i in $(seq ${RETRY}); do
    flag="0"
    rm -rf ./python ./python_annoy.tar.gz || true
    hadoop fs -D hadoop.job.ugi="feed_vertical,Tg28D3" -D fs.default.name=afs://tianqi.afs.baidu.com:9902 -get afs://tianqi.afs.baidu.com:9902/user/feed/vertical/user/guowentao01/miniapp/graph-icf/python_annoy.tar.gz ./ || flag="1"
    tar -zxf ./python_annoy.tar.gz -C ./ || flag="1"
    if [ $flag = 0 ]; then
        break
    else
        continue
    fi
done

# 获取大盘视频向量
#GRAHP_TRY_HOUR=16
# todo， 临时调大一点测试，正式用的时候，改成24吧。
GRAHP_TRY_HOUR=48
INPUT_PATH="0"
TASK_DATE="0"
for((i=0;i<=${GRAHP_TRY_HOUR};i++));
do
    tm=`date -d "$i hour ago" +"%Y%m%d%H"`
    graph_date=${tm:0:8}
    graph_hour=${tm:8:2}
    echo "graph tm $tm"
    echo "graph date $graph_date"
    echo "graph hour $graph_hour"
    INPUT_PATH="afs://xingtian.afs.baidu.com:9902/user/feed_video/job_data/production/ann/graph/video/item_vec/${graph_date}/${graph_hour}"
    echo ${INPUT_PATH}
    hadoop fs -D hadoop.job.ugi="feed_vertical,Tg28D3" -D fs.default.name=afs://xingtian.afs.baidu.com:9902 -test -e ${INPUT_PATH}/_SUCCESS
    if [ $? = 0 ]; then
        echo "model_finish"
        echo ${INPUT_PATH}
        TASK_DATE=${tm}
        echo ${TASK_DATE}
        break
    fi
done

echo "task_date ${TASK_DATE}"

if [ ${i} -gt 12 ]; then
    echo "new_vec_data delay ${i} hours"
    echo "new_vec_data delay ${i} hours" | mutt shijin01@baidu.com,liushaojie06@baidu.com,xiaotao02@baidu.com,yingwenjie@baidu.com,huanghua02@baidu.com,wangpeijian01@baidu.com,liguanghui02@baidu.com,wangchangzhi@baidu.com,wenhao04@baidu.com,zhangxiang20@baidu.com -s "gicf waring delay"
fi

if [ "$TASK_DATE" = "0" ]; then
    echo "model_not_finish"
    echo "two day new_vec_data not exist" | mutt shijin01@baidu.com,liushaojie06@baidu.com,xiaotao02@baidu.com,yingwenjie@baidu.com,huanghua02@baidu.com,wangpeijian01@baidu.com,liguanghui02@baidu.com,wangchangzhi@baidu.com,wenhao04@baidu.com,zhangxiang20@baidu.com -s "gicf waring model_not_finish"
    rm ./$IP_FILE
    exit 1
fi
hadoop fs -D hadoop.job.ugi="feed_vertical,Tg28D3" -D fs.default.name=afs://xingtian.afs.baidu.com:9902 -cat ${INPUT_PATH}/part-* > ./data/graph_video_vec
cat ./data/graph_video_vec | awk -F "\t" '{print $1}' > ./data/video_all_nid

# 遍历视频队列，获取最终结果
for key in local_ec_video kankan_video
do
{
    echo ${key}
    valid_nid_path="0"
    # 不同队列，离线正排的位置不一样，这里需要单独判断。
    if [[ ${key} = "local_ec_video" ]]; then
        input_address="afs://tianqi.afs.baidu.com:9902/user/feed/vertical/job_data/production/xiaotao02/local_ec_shangyang_dict/shangyang_local_ec_video_nid_set"
        for((i=1;i<=6;i++));
        do
            tm=`date -d "$i hour ago" +"%Y%m%d%H"`
            hadoop fs -D hadoop.job.ugi="feed_vertical,Tg28D3" -D fs.default.name=afs://tianqi.afs.baidu.com:9902 -test -e ${input_address}/${tm}
            if [ $? = 0 ]; then
                valid_nid_path=${input_address}/${tm}
                break
            fi
        done
        hadoop fs -D hadoop.job.ugi="feed_vertical,Tg28D3" -D fs.default.name=afs://tianqi.afs.baidu.com:9902 -cat ${valid_nid_path} > ./data/valid_${key}
        cat ./data/valid_${key} | awk -F "\t" '{print $1}' > ./data/valid_nid_${key}
    fi

    if [[ ${key} = "kankan_video" ]]; then
        GRAHP_TRY_DAY=3
        input_address="afs://tianqi.afs.baidu.com:9902/user/feed/vertical/job_data/production/vertical_common/wangmengfei01/fufei/info/"
        for((i=0;i<$GRAHP_TRY_DAY;i++));
        do
            tm=$(date -d "${i} day ago" +%Y%m%d)
            hadoop fs -D hadoop.job.ugi="feed_vertical,Tg28D3" -D fs.default.name=afs://tianqi.afs.baidu.com:9902 -test -e ${input_address}/${tm}/info_${tm}
            if [ $? = 0 ]; then
                valid_nid_path=${input_address}/${tm}/info_${tm}
                break
            fi
        done
        hadoop fs -D hadoop.job.ugi="feed_vertical,Tg28D3" -D fs.default.name=afs://tianqi.afs.baidu.com:9902 -cat ${valid_nid_path} > ./data/valid_${key}
        cat ./data/valid_${key} | awk -F "\t" '{if($2=="video") print $1}' > ./data/valid_nid_${key}
    fi
    #ann检索，依赖白名单nid，建库nid向量
    cat ./data/graph_video_vec | ./python/bin/python ./get_annoy_index.py -w ./data/valid_nid_${key} -v ./data/video_all_nid > ./data/${key}_gicf_dict
    # 写redis
    python ./write_redis_multi_proc_release.py ${key} ./log/log.${hour}_${key} ./data/${key}_gicf_dict
    # todo 统计失败率，如果失败率大于5%，发邮件报警。后续改成把失败的重写一遍redis。
    python cal_fail_ratio.py ./log/log.${hour}_${key}
} &
done
wait

# todo，提商鞅的时候，这里需要修改。
echo ${hour} > ./data/${dict}
md5sum ./data/${dict} > ./data/${dict}.md5 
rm ./$IP_FILE

delete_hour=`date -d "-10 day" +%Y%m%d`
rm -f ./log/*${delete_hour}*
exit 0
