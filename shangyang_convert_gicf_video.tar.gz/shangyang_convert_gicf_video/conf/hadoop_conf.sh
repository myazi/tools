CURDIR=$(cd $(dirname ${BASH_SOURCE[0]}); pwd)

HADOOP_HOME=~/.hmpclient
# 用于annoy
PYTHON=${CURDIR%/*}/python/bin/python

HADOOP_CONF_VERTICAL_FILE=$CURDIR/hadoop-site-vertical.xml
HADOOP_FS="${HADOOP_HOME}/bin/hadoop fs -conf ${HADOOP_CONF_VERTICAL_FILE}"

HDFS_ROOT=/user/feed/vertical/user/liguanghui02
HDFS_TOOL=${HDFS_ROOT}/tools