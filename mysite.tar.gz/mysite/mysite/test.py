from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render
import json
import sys
import time
import os
import xlsxwriter
from django.http import FileResponse  

def index_q(request):
	query = request.GET.get('nid',"-1")
	title = "<h1>Search<h1>"
	contacts = {}
	print(query)

	return render(request, 'index.html', {'contacts': contacts})

def test_q(request):
	
	query = request.GET.get('nid',"-1")
	print(query)
	req_content = []
	title = "<h1>Search<h1>"
	sep= '</td><td>'
	nid_res = {}
	try:
		with open("./mysite/search_res",'r') as fp:
			for line in fp:
				line_list = line.strip('\n').split('\t')
				q, t, p, u, sid, score = line_list[0:6]
				nid_res[sid] = {}
				nid_res[sid]["nid"] = sid
				nid_res[sid]["public_time"] = q 
				nid_res[sid]["title"] = t
				nid_res[sid]["show"] = p
				nid_res[sid]["click"] = u
				nid_res[sid]["ctr"] = score
	except BaseException:
		print("local_res is no found")

	print("result_len=" + str(len(nid_res)))
	one_max = 10000
	for nid, res in nid_res.items():
		req_content.append(res)
		one_max -= 1
		if one_max < 0:
			break
	paginator = Paginator(req_content, 4) # Show 25 contacts per page		  
	page = request.GET.get('page',1)
	try:
		contacts = paginator.page(page)
	except PageNotAnInteger:
		#If page is not an integer, deliver first page.
		contacts = paginator.page(1)
	except EmptyPage:
		#If page is out of range (e.g. 9999), deliver last page of results.
		contacts = paginator.page(paginator.num_pages)										   
	return render(request, 'test.html', {'contacts': contacts})
