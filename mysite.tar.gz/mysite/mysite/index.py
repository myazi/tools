from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render
import json
import sys
import time
import os
import xlsxwriter
from django.http import FileResponse  

def list_all(request):
	
	req_content = []
	title = "<h1>垂类运营<h1>"
	sep= '</td><td>'
	nid_res = {}
	try:
		with open("./mysite/yunying/data/local_res",'r') as fp:
			nid_res = json.load(fp)
	except BaseException:
		print("local_res is no found")

	print("result_len=" + str(len(nid_res)))
	for nid, res in nid_res.items():
		if res['public_time'] > 0 and res['timeliness'] > 0:
			res['timeliness'] = time.localtime(res['public_time'] + res['timeliness'] + 8 * 3600)
			res['timeliness'] = time.strftime("%Y-%m-%d %H:%M:%S",res['timeliness'])
			res['public_time'] = time.localtime(res['public_time'] + 8 * 3600)
			res['public_time'] = time.strftime("%Y-%m-%d %H:%M:%S",res['public_time'])
		
		if res['begin_time'] > 0:
			res['begin_time'] = time.localtime(res['begin_time'] + 8 * 3600)
			res['begin_time'] = time.strftime("%Y-%m-%d %H:%M:%S",res['begin_time'])
		if res['status'] != 'ing' and res['status'] != 'None':	
			res['end_time'] = time.localtime(res['end_time'] + 8 * 3600)
			res['end_time'] = time.strftime("%Y-%m-%d %H:%M:%S",res['end_time'])
	print(len(nid_res))
	one_max = 10000
	for nid, res in nid_res.items():
		req_content.append(res)
		one_max -= 1
		if one_max < 0:
			break
	paginator = Paginator(req_content, 30) # Show 25 contacts per page		  
	page = request.GET.get('page',1)
	try:
		contacts = paginator.page(page)
	except PageNotAnInteger:
		#If page is not an integer, deliver first page.
		contacts = paginator.page(1)
	except EmptyPage:
		#If page is out of range (e.g. 9999), deliver last page of results.
		contacts = paginator.page(paginator.num_pages)										   
	return render(request, 'list.html', {'contacts': contacts})

def list_ing(request):
	
	req_content = []
	title = "<h1>垂类运营<h1>"
	sep= '</td><td>'
	nid_res = {}
	try:
		with open("./mysite/yunying/data/local_res",'r') as fp:
			nid_res = json.load(fp)
	except BaseException:
		print("local_res is no found")

	print("result_len=" + str(len(nid_res)))
	for nid, res in nid_res.items():
		if res['public_time'] > 0 and res['timeliness'] > 0:
			res['timeliness'] = time.localtime(res['public_time'] + res['timeliness'] + 8 * 3600)
			res['timeliness'] = time.strftime("%Y-%m-%d %H:%M:%S",res['timeliness'])
			res['public_time'] = time.localtime(res['public_time'] + 8 * 3600)
			res['public_time'] = time.strftime("%Y-%m-%d %H:%M:%S",res['public_time'])
		
		if res['begin_time'] > 0:
			res['begin_time'] = time.localtime(res['begin_time'] + 8 * 3600)
			res['begin_time'] = time.strftime("%Y-%m-%d %H:%M:%S",res['begin_time'])
		if res['status'] != 'ing' and res['status'] != 'None':	
			res['end_time'] = time.localtime(res['end_time'] + 8 * 3600)
			res['end_time'] = time.strftime("%Y-%m-%d %H:%M:%S",res['end_time'])
	print(len(nid_res))
	one_max = 10000
	for nid, res in nid_res.items():
		if res.get('status',0) == "ing":
			req_content.append(res)
			one_max -= 1
			if one_max < 0:
				break
	paginator = Paginator(req_content, 30) # Show 25 contacts per page		  
	page = request.GET.get('page',1)
	try:
		contacts = paginator.page(page)
	except PageNotAnInteger:
		#If page is not an integer, deliver first page.
		contacts = paginator.page(1)
	except EmptyPage:
		#If page is out of range (e.g. 9999), deliver last page of results.
		contacts = paginator.page(paginator.num_pages)										   
	return render(request, 'list.html', {'contacts': contacts})

def list_bid(request):
	
	bid = request.GET.get('bid',"-1")
	req_content = []
	title = "<h1>垂类运营<h1>"
	sep= '</td><td>'
	nid_res = {}
	try:
		with open("./mysite/yunying/data/local_res",'r') as fp:
			nid_res = json.load(fp)
	except BaseException:
		print("local_res is no found")

	print("result_len=" + str(len(nid_res)))
	for nid, res in nid_res.items():
		if res['public_time'] > 0 and res['timeliness'] > 0:
			res['timeliness'] = time.localtime(res['public_time'] + res['timeliness'] + 8 * 3600)
			res['timeliness'] = time.strftime("%Y-%m-%d %H:%M:%S",res['timeliness'])
			res['public_time'] = time.localtime(res['public_time'] + 8 * 3600)
			res['public_time'] = time.strftime("%Y-%m-%d %H:%M:%S",res['public_time'])
		
		if res['begin_time'] > 0:
			res['begin_time'] = time.localtime(res['begin_time'] + 8 * 3600)
			res['begin_time'] = time.strftime("%Y-%m-%d %H:%M:%S",res['begin_time'])
		if res['status'] != 'ing' and res['status'] != 'None':	
			res['end_time'] = time.localtime(res['end_time'] + 8 * 3600)
			res['end_time'] = time.strftime("%Y-%m-%d %H:%M:%S",res['end_time'])
	print(len(nid_res))
	one_max = 10000
	for nid, res in nid_res.items():
		if res.get('Bid',0) == bid:
			req_content.append(res)
			one_max -= 1
			if one_max < 0:
				break
	paginator = Paginator(req_content, 30) # Show 25 contacts per page		  
	page = request.GET.get('page',1)
	try:
		contacts = paginator.page(page)
	except PageNotAnInteger:
		#If page is not an integer, deliver first page.
		contacts = paginator.page(1)
	except EmptyPage:
		#If page is out of range (e.g. 9999), deliver last page of results.
		contacts = paginator.page(paginator.num_pages)										   
	return render(request, 'list.html', {'contacts': contacts})

def list_nid(request):
	
	nid = request.GET.get('nid',"-1")
	print(nid)
	nid_res = {}
	try:
		with open("./mysite/yunying/data/local_res",'r') as fp:
			nid_res = json.load(fp)
	except BaseException:
		print("local_res is no found")
	res = nid_res.get(nid,{})
	
	if len(res) > 0 and res['public_time'] > 0 and res['timeliness'] > 0:
		res['timeliness'] = time.localtime(res['public_time'] + res['timeliness'] + 8 * 3600)
		res['timeliness'] = time.strftime("%Y-%m-%d %H:%M:%S",res['timeliness'])
		res['public_time'] = time.localtime(res['public_time'] + 8 * 3600)
		res['public_time'] = time.strftime("%Y-%m-%d %H:%M:%S",res['public_time'])
		
	if len(res) > 0 and res['begin_time'] > 0:
		res['begin_time'] = time.localtime(res['begin_time'] + 8 * 3600)
		res['begin_time'] = time.strftime("%Y-%m-%d %H:%M:%S",res['begin_time'])
	if len(res) > 0 and res['status'] != 'ing' and res['status'] != 'None':	
		res['end_time'] = time.localtime(res['end_time'] + 8 * 3600)
		res['end_time'] = time.strftime("%Y-%m-%d %H:%M:%S",res['end_time'])
	print(res)
	res = [res]	
	paginator = Paginator(res, 1) # Show 25 contacts per page		  
	page = request.GET.get('page',1)
	print("page=" + str(page))
	try:
		contacts = paginator.page(page)
	except PageNotAnInteger:
		#If page is not an integer, deliver first page.
		contacts = paginator.page(1)
	except EmptyPage:
		#If page is out of range (e.g. 9999), deliver last page of results.
		contacts = paginator.page(paginator.num_pages)										   
	return render(request, 'list.html', {'contacts': contacts})
def export_excel(request):

	nid_res = {}
	try:
		with open("./mysite/yunying/data/local_res",'r') as fp: # 数据文件地址，用于在web上展示
			nid_res = json.load(fp)
	except BaseException:
		print("local_res is no found")

	print("result_len=" + str(len(nid_res)))
	
	path = "./"
	par_path = './'
	os.chdir(par_path)
	file = "all_data.xlsx"
	fields = ['nid', 'title', 'Bid', 'Pid', '作者等级','内容得分',"发布时间","过期时间","保量开始时间","保量结束时间","保量天数","保量等级","当前状态","阅读时长","阅读完成率","dislike次数","评论数","展现量","点击量","点展比"]
	workbook = xlsxwriter.Workbook(file)
	worksheet = workbook.add_worksheet('data')

	#表头格式
	format1 = workbook.add_format({'bold': True, 'font_color': 'black', 'font_size': 13, 'align': 'left', 'font_name': u'宋体'})
	#表头外格式
	format2 = workbook.add_format({'font_color': 'black', 'font_size': 9, 'align': 'left', 'font_name': u'宋体'})
	# A列列宽设置能更好的显示
	worksheet.set_column("A:A", 9)
	# 插入第一行表头标题
	for i in range(0, len(fields)):
		field = fields[i]
		worksheet.write(0, i, field, format1)
	#从第二行开始插入数据
	i = 1
	for nid, res in nid_res.items():
		nid = res.get('nid',0)
		title = res.get('title',0)
		Bid = res.get('Bid',0)
		Pid = res.get('Pid',0)
		author_level = res.get('author_level',0)
		content_score = res.get('content_score',0)
		public_time = res.get('public_time',0)
		timeliness = res.get('timeliness',0)
		begin_time = res.get('begin_time',0)
		end_time = res.get('end_time',0)
		ensure_day = res.get('ensure_day',0)
		ensure_level = res.get('ensure_level',0)
		status = res.get('status',0)
		read_time = res.get('read_time',0)
		read_ratio = res.get('read_ratio',0)
		dislike = res.get('dislike',0)
		disscuss_num = res.get('disscuss',0)
		show = res.get('show',0)
		click = res.get('click',0)
		ctr = res.get('ctr',0)

		if public_time > 0 and timeliness > 0:
			timeliness = time.localtime(public_time + timeliness + 8 * 3600)
			timeliness = time.strftime("%Y-%m-%d %H:%M:%S",timeliness)
			public_time = time.localtime(public_time + 8 * 3600)
			public_time = time.strftime("%Y-%m-%d %H:%M:%S",public_time)
		
		if begin_time > 0:
			begin_time = time.localtime(begin_time + 8 * 3600)
			begin_time = time.strftime("%Y-%m-%d %H:%M:%S",begin_time)
		if status != 'ing' and status != 'None':	
			end_time = time.localtime(end_time + 8 * 3600)
			end_time = time.strftime("%Y-%m-%d %H:%M:%S",end_time)
		worksheet.write(i,0,nid,format2)
		worksheet.write(i,1,title,format2)
		worksheet.write(i,2,Bid,format2)
		worksheet.write(i,3,Pid,format2)
		worksheet.write(i,4,author_level,format2)
		worksheet.write(i,5,content_score,format2)
		worksheet.write(i,6,public_time,format2)
		worksheet.write(i,7,timeliness,format2)
		worksheet.write(i,8,begin_time,format2)
		worksheet.write(i,9,end_time,format2)
		worksheet.write(i,10,ensure_day,format2)
		worksheet.write(i,11,ensure_level,format2)
		worksheet.write(i,12,status,format2)
		worksheet.write(i,13,read_time,format2)
		worksheet.write(i,14,read_ratio,format2)
		worksheet.write(i,15,dislike,format2)
		worksheet.write(i,16,disscuss_num,format2)
		worksheet.write(i,17,show,format2)
		worksheet.write(i,18,click,format2)
		worksheet.write(i,19,ctr,format2)
		i += 1

	workbook.close()
	alert_text = '导出%s条数据到excel成功' % len(nid_res)
	file=open('./all_data.xlsx','rb')
	response =FileResponse(file)
	response['Content-Type']='application/octet-stream'
	response['Content-Disposition']='attachment;filename="all_data.xlsx"'
	return response
	#return render(request, 'list.html', {'alert_text': alert_text })
