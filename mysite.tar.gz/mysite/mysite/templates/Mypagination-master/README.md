# Mypagination
Django数据分页（效果图如下：）

![avatar](./statics/pic.png)