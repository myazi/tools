"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from django.urls import path
from mysite.index import list_all
from mysite.index import list_ing
from mysite.index import list_bid
from mysite.index import list_nid
from mysite.index import export_excel
from mysite.test import test_q
from mysite.test import index_q


urlpatterns = [
    path('admin/', admin.site.urls),
	url('^index/',list_all),
	url('^list_2/',list_ing),
	url('^list_3/',list_bid),
	url('^list_4/',list_nid),
	url('^test/',test_q),
	url('^search/',index_q),
	url('^export_excel',export_excel)
]
